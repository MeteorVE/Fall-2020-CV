import numpy as np
import matplotlib.pyplot as plt
import cv2

import random
import math

def add_padding(img, radius_pair, fill_value=0):
    """ radius_pair: w,h of selem/2  """
    w, h = img.shape
    new_img = np.full( (w+radius_pair[0]*2, h+radius_pair[1]*2), fill_value, dtype=np.uint8 )
    new_img[ radius_pair[0]:radius_pair[0]+w, radius_pair[1]:radius_pair[1]+h ] = img
    return new_img

def dilation(img, kernel):
    padding_img = add_padding(img, (2,2), 0)
    img_result  = img.copy()

    # check the max of kernel shape
    w, h = img.shape
    kw, kh = 2, 2
    for x in range(2, w+2):
        for y in range(2, h+2):
            local_max = 0
            for a, b in kernel:
                if local_max < padding_img[x+a, y+b]:
                    local_max = padding_img[x+a, y+b]
            img_result[x-2, y-2] = local_max

    return img_result

def erosion(img, kernel):
    padding_img = add_padding(img, (2,2), 255)
    img_result  = img.copy() #add_padding(img, (2,2), 255)

    # check the max of kernel shape
    w, h = img.shape
    kw, kh = 2, 2
    for x in range(2, w+2):
        for y in range(2, h+2):
            
            local_min = 255
            for a, b in kernel:
                if local_min > padding_img[x+a, y+b]:
                    local_min = padding_img[x+a, y+b]

            img_result[x-2, y-2] = local_min

    return img_result

def opening(img, kernel):
    return dilation(erosion(img, kernel),kernel)

def closing(img, kernel):
    return erosion(dilation(img, kernel),kernel)



def generate_gaussian_noise_img(img, amplitude):
    """
    :type img: Image(numpy 2d)
    :type amplitude: int
    :return type: Image
    """

    w, h = img.shape
    new_img = img.copy()
    for x in range(w):
        for y in range(h):
            new_pixel_value = img[x][y] + amplitude * random.gauss(0, 1)

            if new_pixel_value < 0:
                new_pixel_value = 0
            if new_pixel_value > 255:
                new_pixel_value = 255
            
            new_img[x][y] = new_pixel_value
    return new_img

def generate_salt_and_pepper_img(img, probability):
    """
    :type img: Image(numpy 2d)
    :type probability: double
    :return type: Image 
    """

    w, h = img.shape
    new_img = img.copy()
    for x in range(w):
        for y in range(h):
            rnd_value = random.uniform(0, 1)
            
            if rnd_value <= probability:
                new_img[x][y] = 0
            elif rnd_value >= 1 - probability:
                new_img[x][y] = 255
            else:
                continue
    return new_img

def box_filter(img, filter_size):
    """
    :type img: Image(numpy 2d)
    :type filter_size: pair
    :return type: Image 
    """

    w, h = img.shape
    fw, fh = filter_size
    new_img = img.copy()

    for x in range( w ):
        for y in range( h ):
            sum_val = 0
            cnt = 0
            for a in range( -fw//2+1, fw//2+1 ):
                for b in range( -fh//2+1, fh//2+1 ):
                    tx, ty = x+a, y+b
                    if 0 <= tx < w and 0 <= ty < h:
                        sum_val += img[tx][ty]
                        cnt += 1
            avg_pixel_value = sum_val//(cnt) 
            #avg_pixel_value = img[x-fw//2: x+fw//2+1, y-fh//2: y+fh//2+1].sum()//(fw*fh) # Notice: Edge will not be updated
            
            # Notice: Non-recurrsive
            new_img[x][y] = avg_pixel_value

    return new_img

def median_filter(img, filter_size):
    """
    :type img: Image(numpy 2d)
    :type filter_size: pair
    :return type: Image 
    """

    w, h = img.shape
    fw, fh = filter_size
    new_img = img.copy()

    for x in range( w ):
        for y in range( h ):
            tmp_arr = []
            for a in range( -fw//2+1, fw//2+1 ):
                for b in range( -fh//2+1, fh//2+1 ):
                    tx, ty = x+a, y+b
                    if 0 <= tx < w and 0 <= ty < h:
                        tmp_arr.append(img[tx][ty])
            sorted_array = np.sort(tmp_arr, axis=None)
            median_value = sorted_array[len(tmp_arr)//2]

            # Notice: Non-recurrsive
            new_img[x][y] = median_value
    return new_img


def calc_snr(img, noise_img):
    """
    :type img: Image(numpy 2d)
    :type noise_img: Image(numpy 2d)
    :return type: double 
    """

    w, h = img.shape # img and noise_img are the same size.

    vs, mu_s, vn, mu_n = 0, 0, 0, 0

    for x in range(w):
        for y in range(h):
            mu_s += img[x][y]
            mu_n += (int(noise_img[x][y]) - int(img[x][y]))

    mu_s = mu_s / (w*h)
    mu_n = mu_n / (w*h)

    for x in range(w):
        for y in range(h):
            vs += math.pow((img[x][y] - mu_s), 2)
            vn += math.pow((int(noise_img[x][y]) - int(img[x][y]) - int(mu_n)), 2)

    vs = vs / (w*h)
    vn = vn / (w*h)
    return 20 * math.log10( math.sqrt(vs) / math.sqrt(vn) )

def main():


    img = cv2.imread('lena.bmp',0)
    #nimg = cv2.imread('median_5x5.bmp',0)
    kernel =  [(-2,-1),(-2,0),(-2,1),(-1,-2),(-1,-1),(-1,0),(-1,1),(-1,2),(0,-2),(0,-1),(0,0),(0,1),(0,2),(1,-2),(1,-1),(1,0),(1,1),(1,2),(2,-1),(2,0),(2,1)] 

    gauss_noise_10 = generate_gaussian_noise_img(img, 10)
    gauss_noise_30 = generate_gaussian_noise_img(img, 30)
    salt_noise_005 = generate_salt_and_pepper_img(img, 0.05)
    salt_noise_01  = generate_salt_and_pepper_img(img, 0.1)

    # run 1. 3x3 box filter, 2. 5x5 box filter, 3. 3x3 median filter , 4. 5x5 median filter, 5. opening-then-closing, 6. closing-then-opening 
    result_arr = [[gauss_noise_10], [gauss_noise_30], [salt_noise_005], [salt_noise_01]]

    for i in range(len(result_arr)):
        result_arr[i].append( box_filter(result_arr[i][0], (3,3)) )
        result_arr[i].append( box_filter(result_arr[i][0], (5,5)) )
        result_arr[i].append( median_filter(result_arr[i][0], (3,3)) )
        result_arr[i].append( median_filter(result_arr[i][0], (5,5)) )
        result_arr[i].append( closing(opening(result_arr[i][0], kernel), kernel)  )
        result_arr[i].append( opening(closing(result_arr[i][0], kernel), kernel)  )

    print("Ending generate filtered image.", flush = True)
    print("Start to save image and output snr value.", flush = True)

    names = ["gauss_noise_10", "gauss_noise_30", "salt_noise_005", "salt_noise_01"]
    f = open("snr.txt", "w")
    for i in range(len(result_arr)):
        print(i)
        cv2.imwrite(names[i]+'_box_3x3.bmp', result_arr[i][1])
        cv2.imwrite(names[i]+'_box_5x5.bmp', result_arr[i][2])
        cv2.imwrite(names[i]+'_median_3x3.bmp', result_arr[i][3])
        cv2.imwrite(names[i]+'_median_5x5.bmp', result_arr[i][4])
        cv2.imwrite(names[i]+'_opening_then_closing.bmp', result_arr[i][5])
        cv2.imwrite(names[i]+'_closing_then_opening.bmp', result_arr[i][6])

        f.write(names[i]+'_box_3x3 : ' + str(calc_snr(img, result_arr[i][1])) + '\n')
        f.write(names[i]+'_box_5x5 : ' + str(calc_snr(img, result_arr[i][2])) + '\n')
        f.write(names[i]+'_median_3x3 : ' + str(calc_snr(img, result_arr[i][3])) + '\n')
        f.write(names[i]+'_median_5x5 : ' + str(calc_snr(img, result_arr[i][4])) + '\n')
        f.write(names[i]+'_opening_then_closing : ' + str(calc_snr(img, result_arr[i][5])) + '\n')
        f.write(names[i]+'_closing_then_opening : ' + str(calc_snr(img, result_arr[i][6])) + '\n')
    f.close()


    # === TEST AREA === #
    #print(calc_snr(img,   median_filter(salt_noise_01, (5,5)) ))
    #result = cv2.boxFilter(salt_noise_01, -1, (3, 3), normalize = 1)
    #print(calc_snr(img, result))
    #print(calc_snr(img,  nimg))

if __name__ == '__main__':
    main()





# === TESTING AREA === #
